﻿.NET5 For Azure function 
I using Microsoft visual studio version 2019 Version 16.11.0
And Azure development

Useful URL for get start Azure function in Logic app

https://docs.microsoft.com/en-us/azure/logic-apps/logic-apps-overview

https://docs.microsoft.com/en-us/azure/azure-functions/dotnet-isolated-process-developer-howtos?tabs=browser&pivots=development-environment-vs

https://docs.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=csharp

https://docs.microsoft.com/en-us/azure/logic-apps/tutorial-process-mailing-list-subscriptions-workflow

https://docs.microsoft.com/en-us/azure/connectors/connectors-create-api-sqlazure

